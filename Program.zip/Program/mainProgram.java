
public class mainProgram {

	public static void main(String args[])
	{
		new LaplacianFaces();
	}	
}
