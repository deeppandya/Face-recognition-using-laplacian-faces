
import java.lang.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class imageFunctions
{
	private String tFilePath;

	private String type;
	private String comment;
	private int cols,rows,maxgray;

	private int[][] pixel;
	
	public imageFunctions()
	{
		tFilePath="";
		type="";
		comment="";
		cols=0;
		rows=0;
		maxgray=0;
		pixel=null;
	}

	public String getFilePath()
	{
		return(tFilePath);
	}

	public String getType()
	{
		return(type);
	}

	public String getComment()
	{
		return(comment);
	}

	public int getCols()
	{
		return(cols);
	}

	public int getRows()
	{
		return(rows);
	}

	public int getMaxGray()
	{
		return(maxgray);
	}

	public int getPixel(int tr,int tc)
	{
		return(tr<0||tr>rows-1||tc<0||tc>cols-1?0:pixel[tr][tc]);
	}

	public void setFilePath(String ttFilePath)
	{
		tFilePath=ttFilePath;
	}

	public void setType(String ttype)
	{
		type=ttype;
	}

	public void setComment(String tcomment)
	{
		comment=tcomment;
	}

	public void setDimension(int tcols,int trows)
	{
		rows=trows;
		cols=tcols;
		pixel=new int[rows][cols];
	}

	public void setMaxGray(int tmaxgray)
	{
		maxgray=tmaxgray;
	}

	public void setPixel(int tr,int tc,int tpval)
	{
		if(tr<0||tr>rows-1||tc<0||tc>cols-1) return;
		else pixel[tr][tc]=tpval;
	}

	public void readImage()
	{
		FileInputStream fin;
		
		try
		{
			fin=new FileInputStream(tFilePath);
	
		    int tr,tc,c;
		    String tstr;
		    
		    
		    tstr="";
		    c=fin.read();
		    tstr+=(char)c;
		    c=fin.read();
		    tstr+=(char)c;
		    type=tstr;


		    c=fin.read(); 
		    c=fin.read(); 
			tstr="";
		    boolean iscomment=false;
		    while((char)c=='#') 
		    {
				iscomment=true;
			    tstr+=(char)c;
		        while(c!=10&&c!=13)
		        {
		            c=fin.read();
				    tstr+=(char)c;
		     	}
		        c=fin.read(); 
		 	}
		    comment=tstr;
		    
		    
			if(iscomment==true) c=fin.read();
		    tstr+=(char)c;
		    while(c!=32&&c!=10&&c!=13)
		    {
		        c=fin.read();
		        tstr+=(char)c;
		 	}
		    tstr=tstr.substring(0,tstr.length()-1);
		    cols=Integer.parseInt(tstr);
		    

			c=fin.read();
			tstr="";
		    tstr+=(char)c;
		    while(c!=32&&c!=10&&c!=13)
		    {
		        c=fin.read();
		        tstr+=(char)c;
		 	}
		    tstr=tstr.substring(0,tstr.length()-1);
		    rows=Integer.parseInt(tstr);
		    
		    //read maxgray
			c=fin.read();
			tstr="";
		    tstr+=(char)c;
		    while(c!=32&&c!=10&&c!=13)
		    {
		        c=fin.read();
		        tstr+=(char)c;
		 	}
		    tstr=tstr.substring(0,tstr.length()-1);
		    maxgray=Integer.parseInt(tstr);
		    

			pixel=new int[rows][cols];
		    for(tr=0;tr<rows;tr++)
		    {
		    	for(tc=0;tc<cols;tc++)
		    	{
		    		c=(int)fin.read();
		    		setPixel(tr,tc,c);
		    	}
		    }
		    
			fin.close();
		}
		catch(Exception e)
		{
			System.out.println("Error: "+e.getMessage());
		}
	}

	public void writeImage()
	{
		FileOutputStream fout;
		
		try
		{
			fout=new FileOutputStream(tFilePath);
			
			
			String tstr;
			tstr="P5"+"\n";
			fout.write(tstr.getBytes());
			

			comment=comment+"\n";


			tstr=Integer.toString(cols);
			fout.write(tstr.getBytes());
			fout.write(32); //write blank space
			

			tstr=Integer.toString(rows);
			fout.write(tstr.getBytes());
			fout.write(32); //write blank space
			

			tstr=Integer.toString(maxgray);
			tstr=tstr+"\n";
			fout.write(tstr.getBytes());
			
			for(int r=0;r<rows;r++)
			{
				for(int c=0;c<cols;c++)
				{
					fout.write(getPixel(r,c));
				}
			}

			fout.close();
		}
		catch(Exception e)
		{
			System.out.println("Error: "+e.getMessage());
		}
	}

	public void copyImage(String tstrOuttFilePath)
	{
		imageFunctions imgout=new imageFunctions();

		
		imgout.setFilePath(tstrOuttFilePath);
		imgout.setType(getType());
		imgout.setComment(getComment());
		imgout.setDimension(getCols(),getRows());
		imgout.setMaxGray(getMaxGray());
		for(int r=0;r<getRows();r++)
		{
			for(int c=0;c<getCols();c++)
			{
				imgout.setPixel(r,c,getPixel(r,c));
			}
		}
		imgout.writeImage();
	}
}
