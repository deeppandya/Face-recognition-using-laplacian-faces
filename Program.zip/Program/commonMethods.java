import java.awt.Color;
import java.awt.Graphics;


public class commonMethods {
	
	static void drawImage(Graphics g,String tPath)
	{
		imageFunctions tpgm=new imageFunctions();
		tpgm.setFilePath(tPath);
		tpgm.readImage();
		
		g.clearRect(0,0,200,150);
		for(int r=0;r<tpgm.getRows();r++)
		{
			for(int c=0;c<tpgm.getCols();c++)
			{
				int intensity=tpgm.getPixel(r,c);
				Color color=new Color(intensity,intensity,intensity);
				g.setColor(color);
				g.fillRect(c,r+30,1,1);
			}
		}
	}

}
