import java.lang.*;
import java.io.*;
import java.lang.Math.*;

public class imageFilterFunctions
{
	String inFilePath,outFilePath;
	boolean printStatus=false;

	public imageFilterFunctions()
	{
		inFilePath="";
		outFilePath="";
	}

	public String get_inFilePath()
	{
		return(inFilePath);
	}
	
	public String get_outFilePath()
	{
		return(outFilePath);
	}
	
	public void set_inFilePath(String tFilePath)
	{
		inFilePath=tFilePath;
	}
	
	public void set_outFilePath(String tFilePath)
	{
		outFilePath=tFilePath;
	}
	
	public void resize(int wout,int hout)
	{
		imageFunctions imgin=new imageFunctions();
		imageFunctions imgout=new imageFunctions();
	
		if(printStatus==true)
		{
			System.out.print("\nResizing...");
		}
		int r,c,inval,outval;
	
		imgin.setFilePath(inFilePath);
		imgin.readImage();
	
		imgout.setFilePath(outFilePath);
		imgout.setType("P5");
		imgout.setComment("#resized image");
		imgout.setDimension(wout,hout);
		imgout.setMaxGray(imgin.getMaxGray());
	
		double win,hin;
		int xi,ci,yi,ri;
	
		win=imgin.getCols();
		hin=imgin.getRows();
	
		for(r=0;r<imgout.getRows();r++)
		{
			for(c=0;c<imgout.getCols();c++)
			{
				xi=c;
				yi=r;
	
				ci=(int)(xi*((double)win/(double)wout));
				ri=(int)(yi*((double)hin/(double)hout));
				
				inval=imgin.getPixel(ri,ci);
				outval=inval;
	
				imgout.setPixel(yi,xi,outval);
			}
		}
	
		if(printStatus==true)
		{
			System.out.println("done.");
		}
		
		imgout.writeImage();
	}
	
}
